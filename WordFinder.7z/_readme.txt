
This program searches a provided word in a given board

1) See example.jpg ... it explains how the searches are conducted

2) Execute build.bat to compile and create the executable jar file to test the program

3) Execute the jar file          java -jar WordFinder.jar
   enter words to search


 